To build, you must have protobuffers compiled on your computer.  The version should
match the one in the POM.  Download the library from here:
http://code.google.com/p/protobuf/downloads/list